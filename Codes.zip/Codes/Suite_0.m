function max = Suite_0(M)
  c=0;
  x=1;
  max=1;
  for i = 1:length(M)-1   
      if M(i)==0
          c=1  ;       
          if M(i)==M(i+1)
              c=x+1;
              x=c;
              if max<x
                  max=x;
              end
          else
              x=1;
              c=0;    
          end
      end 
  end