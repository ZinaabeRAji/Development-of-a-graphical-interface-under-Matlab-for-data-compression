function x = Verticale(M)
[n,m] = size(M) 
x=[]
for i=1:n
    for j = 1:m
       x = [x M(j,i)]
    end
end
end