
%************************************************************************%
%  --Title: conversion du code huffman                                       %
%  --TP1: Cha�ne de transmission et techniques de quantifications        %
%************************************************************************%
%  --File: Entropy.m                                                     %

%************************************************************************%
%  --Description:Fonction qui qui convertie en binaire le codage huffman %
%************************************************************************%


%************************************************************************%
%                            MATLAB Program                              %
%************************************************************************%

function huff_convert(m)

for i=1:length(m)
     dict{i,2}=num2str(m{i,2});
end

dict
 