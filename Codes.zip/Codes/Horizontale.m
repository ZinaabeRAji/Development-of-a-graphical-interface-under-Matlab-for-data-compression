function y = Horizontale(M)
[n,m] = size(M) 
y=[]
for i=1:n
    for j = 1:m
    y = [y M(i,j)]
    end
end
end